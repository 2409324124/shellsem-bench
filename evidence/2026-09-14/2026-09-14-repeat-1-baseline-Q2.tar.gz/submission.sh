collect() {
    local count=0 first_worker=0 scan_status=0 framing=0 item

    while IFS= read -r -d '' item; do
        ((count++)) || true
        if worker -- "$item" <&- 2>&2; then
            :
        else
            local ec=$?
            if (( first_worker == 0 )); then
                first_worker=$ec
            fi
        fi
    done < <(scanner -- "$1" 2>/dev/null) 3>&-
    scan_status=$?

    if IFS= read -r -n 1 _tail <&0 3>&-; then
        framing=65
    fi

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_status" "$first_worker" "$framing" >&3

    if (( scan_status != 0 )); then
        return "$scan_status"
    elif (( framing != 0 )); then
        return 65
    else
        return "$first_worker"
    fi
}
