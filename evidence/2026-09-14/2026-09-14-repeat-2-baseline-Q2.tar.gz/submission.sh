collect() {
    local count=0 first_worker=0 scan_status=0 framing=0 item

    while IFS= read -r -d '' item; do
        (( ++count )) || true
        if worker -- "$item" <&- 2>&2; then
            :
        else
            local rc=$?
            if (( first_worker == 0 )); then
                first_worker=$rc
            fi
        fi
    done < <(scanner -- "$1")

    scan_status=$?

    if IFS= read -r -n 1 trailing; then
        framing=65
    fi

    local ret=0
    if (( scan_status != 0 )); then
        ret=$scan_status
    elif (( framing != 0 )); then
        ret=65
    else
        ret=$first_worker
    fi

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_status" "$first_worker" "$framing" >&3

    return "$ret"
}
