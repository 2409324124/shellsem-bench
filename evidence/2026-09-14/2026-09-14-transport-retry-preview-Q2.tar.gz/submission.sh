collect() {
    local root=$1 count=0 first=0 item rc=0 framing=0 pid

    exec 4< <(scanner -- "$root" </dev/null)
    pid=$!

    while IFS= read -r -u 4 -d '' item; do
        count=$((count + 1))
        worker -- "$item" </dev/null 4<&-
        rc=$?
        if ((rc != 0 && first == 0)); then
            first=$rc
        fi
    done

    if [[ -n $item ]]; then
        framing=65
    fi

    exec 4<&-
    rc=0
    wait "$pid" || rc=$?

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$rc" "$first" "$framing" >&3

    if ((rc != 0)); then
        return "$rc"
    elif ((framing != 0)); then
        return "$framing"
    else
        return "$first"
    fi
}
