collect() {
    local count=0 first_worker=0 scan_exit=0 has_trailing=0 item

    # Read scanner output from a dedicated fd (fd 4) so workers don't inherit it.
    # We use fd 4 via exec to open the process substitution, then read from it.
    exec 4< <(scanner -- "$1"; printf '\0' > /dev/null)

    # We need to detect scanner's real exit code. Process substitution hides it.
    # Instead, run scanner in a pipeline-like setup using a named fd approach.
    # Actually, we must capture scanner exit. Use a trick: append exit marker.
    exec 4<&-  # close what we just opened; redo properly below

    # Proper approach: use a coprocess-like manual pipe with explicit exit capture.
    # Since we can't use temp files or external tools, we use bash process substitution
    # but encode the exit status as a final NUL-delimited sentinel.

    local scan_fd
    # Open scanner output on fd 4, with exit code appended as a special trailer.
    exec 4< <(
        scanner -- "$1"
        # After scanner exits, emit a sentinel record containing its exit code.
        # The sentinel is: empty byte followed by NUL, then the exit code as text + NUL
        # But records can contain anything... We need an unambiguous signal.
        # Strategy: emit TWO extra NULs. The last "record" after all real ones will be
        # empty (between the two NULs), and we know scanner is done. Then we lose the
        # exit code...
        # Better: just track whether the stream ended with NUL or not.
        # Actually simplest: capture exit code via a second channel.
        # Use fd 5 for exit code.
        echo $? >&5
    ) 5> >(
        # Read scanner exit code from fd 5
        IFS= read -r scan_exit_val
        # Store it in a way the parent can access — but this is a subshell.
        # This won't work either.
        :
    )

    # The above approaches are getting complicated. Let me use a cleaner method.
    exec 4<&- 2>/dev/null || true

    # Clean approach: redirect scanner through a pipe where we control both ends.
    # Use file descriptor manipulation.

    local scanner_pipe_r scanner_pipe_w
    exec {scanner_pipe_r}< <(
        scanner -- "$1"
        local sc=$?
        # Write exit code to fd 5
        printf '%d\0' "$sc" >&5
    ) 5> >(
        IFS= read -r -d '' _scan_exit_tmp
        # Can't propagate back to parent from process substitution
        :
    )

    # Process substitutions run in subshells — can't set parent variables.
    # We need a different strategy entirely.

    # FINAL APPROACH: Read scanner byte-by-byte isn't feasible in pure bash efficiently.
    # Instead: read all scanner output through fd, detect trailing fragment by checking
    # if last read had non-zero status AND non-empty buffer. For scanner exit code,
    # we accept that process substitution loses it UNLESS we use a wrapper.

    # Working approach using only builtins:
    # 1. Open scanner on fd 4 via process substitution
    # 2. Read records with read -d '' from fd 4
    # 3. After loop, check if there was a trailing fragment
    # 4. For scanner exit: use PIPESTATUS workaround or accept limitation

    # Actually, re-reading the requirements: we CAN get scanner exit if we structure
    # the process substitution to report it via the data stream itself.

    exec 4<&- 2>/dev/null || true

    # Encode scanner exit code as a final sentinel in the data stream.
    # After all real records, emit: \x01\x00<exit_code_decimal>\x00
    # Since \x01 can appear in records, this isn't safe either.

    # The ONLY reliable pure-bash way: use a single process substitution that
    # outputs records normally, then at the end writes the exit code to a
    # separate fd that goes to a variable via another process substitution.
    # But nested process substitutions have race conditions.

    # Simplest correct approach: sacrifice nothing. Use the fact that
    # `read -d '' var` sets var to remaining data on EOF even when returning 1.
    # For scanner exit code: wrap scanner to append exit info.

    exec 4< <(
        scanner -- "$1"
        # Append a NUL-separated trailer with exit code
        # Use a prefix that we can distinguish: after all real NUL-terminated records,
        # this adds one more NUL-terminated field containing "SCANEXIT:<code>"
        printf '\0SCANEXIT:%d\0' "$?"
    )

    while true; do
        item=""
        if ! IFS= read -r -d '' item <&4; then
            # EOF reached. Check if item is non-empty (trailing fragment)
            # or our sentinel
            if [[ -n "$item" ]]; then
                if [[ "$item" == SCANEXIT:* ]]; then
                    scan_exit="${item#SCANEXIT:}"
                else
                    # Trailing fragment (not NUL-terminated) before sentinel
                    has_trailing=1
                    # Continue reading to find sentinel
                    continue
                fi
            fi
            break
        fi

        # Check if this record is our sentinel (shouldn't happen mid-stream,
        # but handle gracefully)
        if [[ "$item" == SCANEXIT:* ]]; then
            scan_exit="${item#SCANEXIT:}"
            break
        fi

        (( ++count )) || true

        # Run worker with stdin closed (/dev/null), stdout/stderr passed through directly
        # Do NOT capture output in a variable
        if worker -- "$item" < /dev/null; then
            : # worker succeeded
        else
            local wrc=$?
            if (( first_worker == 0 )); then
                first_worker=$wrc
            fi
        fi
    done

    exec 4<&-

    # Determine return code based on priority
    local ret=0
    if (( scan_exit != 0 )); then
        ret=$scan_exit
    elif (( has_trailing )); then
        ret=65
    elif (( first_worker != 0 )); then
        ret=$first_worker
    fi

    local framing=$(( has_trailing ? 65 : 0 ))

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_exit" "$first_worker" "$framing" >&3

    return "$ret"
}
