这是一次 Bash 语义推理测试。**允许使用提供的 read、write、edit、bash 工具验证推导。最终答复仍须满足下述格式。**

环境固定为 **GNU Bash 5.2.37、Linux、非交互、非 POSIX 模式**。初始环境干净，没有额外的 trap、函数、别名或 shell 配置。stdout、stderr 分别捕获，不合并。所有 I/O 操作成功，没有外部信号。

脚本如下：
```bash
set -Eeuo pipefail
shopt -u lastpipe inherit_errexit
set +m
export LC_ALL=C
IFS=$' \t\n'
exec 3>&1
trap 's=$?; printf "ERR:%s:%s\n" "$BASH_SUBSHELL" "$s" >&3' ERR

f() {
    local v
    v="$(
        printf 'A\n'
        (exit 7)
        printf 'B\n\n'
    )"
    printf 'F:%q\n' "$v"
    return 9
}

if captured="$(f 2>&1)"; then
    code=0
else
    code=$?
fi
printf 'A:%s:%q\n' "$code" "$captured"

g() {
    local v="$(printf 'C\n'; (exit 4); printf 'D\n\n')"
    printf 'G:%q\n' "$v"
}
g
shopt -s inherit_errexit
g

n=0
if
    (printf 'x\ny\n'; exit 5) |
    { while IFS= read -r v; do printf '%s\n' "$v"; done; (exit 7); } |
    { while IFS= read -r v; do ((n++)); done; (exit 3); }
then
    snap=("$?" "${PIPESTATUS[@]}")
else
    snap=("$?" "${PIPESTATUS[@]}")
fi
printf 'P:%s:n=%s\n' "${snap[*]}" "$n"

s="$(
    { printf 'OUT\n'; printf 'IN\n' >&2; } 2>&1 1>&3
)"
printf 'R:%q\n' "$s"
```

请给出以下 **两种独立运行** 的结果。

**A：** 原脚本。

**B：** 仅把开头的：
```bash
shopt -u lastpipe inherit_errexit
```

替换为：
```bash
shopt -u inherit_errexit
shopt -s lastpipe
```

其他代码不变。

**作答格式：**

先输出一个 JSON 对象，包含 `A`、`B` 两个键。每个键对应一个对象，必须包含：
```json
{
  "stdout": "完整标准输出",
  "stderr": "完整标准错误",
  "exit_code": 0
}
```

其中的值由你推导，示例中的 `0` 不代表答案。严格区别真实换行与字面量反斜杠加 `n`；不要把程序打印出来的引号或反斜杠自行去掉。

JSON 后，用不超过 **500 字**解释关键控制流、退出状态和文件描述符去向。解释必须对应这段程序，不能只罗列通用 Bash 规则。

工具工作目录为 /workspace；bash 为 GNU Bash 5.2.37。隐藏验收数据不可见，不提供答案反馈。
