collect() {
    local root=$1 item='' count=0 scan=0 worker=0 framing=0 rc=0

    # Run scanner exactly once; read its NUL-separated stream on a private fd.
    # The reader's stdin is /dev/null, so the caller's stdin is never consumed
    # and every worker inherits an already-EOF stdin.
    exec {_fd}< <(scanner -- "$root" </dev/null) || return 255

    while IFS= read -r -u "$_fd" -d '' item; do
        (( ++count ))
        # stderr stays inherited (byte-exact); stdout goes to our stdout via
        # the swap trick, which also hides the scanner pipe from the worker.
        worker -- "$item" </dev/null >&3 3>&- || {
            rc=$?
            (( worker == 0 )) && worker=$rc
        }
    done

    # Whatever remains in the buffer is an unterminated tail fragment.
    if IFS= read -r -u "$_fd" -d '' item || [[ -n $item ]]; then
        framing=65
    fi
    item=''

    # Close only the descriptor this function created, then reap the scanner.
    eval "exec $_fd<&-"
    wait "$!" 2>/dev/null
    scan=$?

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan" "$worker" "$framing" >&3

    if   (( scan != 0 ));    then return "$scan"
    elif (( framing != 0 )); then return 65
    else                          return "$worker"
    fi
}
