collect() {
    local count=0 first_worker=0 scan_status=0 framing=0
    local item="" spid=""

    # Run scanner via coproc; dup its read fd to fd 4 so it survives
    # external-command invocations inside the loop (bash invalidates the
    # original coproc fd after forking).  Close the original immediately.
    coproc _SC { scanner -- "$1"; }
    exec 4<&"${_SC[0]}"
    eval "exec ${_SC[0]}<&-"
    spid="${_SC_PID}"

    while IFS= read -r -d '' item <&4; do
        (( ++count )) || true

        # Worker's stdout → our stdout, stderr → our stderr (byte-perfect).
        # stdin is /dev/null (immediate EOF).  fd 4 has CLOEXEC so worker
        # does not inherit it.
        worker -- "$item" < /dev/null || {
            local wrc=$?
            if (( first_worker == 0 )); then
                first_worker=$wrc
            fi
        }
    done

    # Detect unterminated tail fragment: read returned false with leftover data.
    if [[ -n "$item" ]]; then
        framing=65
    fi

    # Clean up fd 4 and collect scanner exit status.
    exec 4<&-
    wait "$spid" 2>/dev/null && scan_status=0 || scan_status=$?

    # Report (all four values are their true independent values).
    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_status" "$first_worker" "$framing" >&3

    # Return priority: scanner > framing > first_worker > 0
    if (( scan_status != 0 )); then
        return "$scan_status"
    elif (( framing != 0 )); then
        return 65
    elif (( first_worker != 0 )); then
        return "$first_worker"
    else
        return 0
    fi
}
