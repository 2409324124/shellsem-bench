collect() {
    local root=$1 count=0 firstw=0 scanrc=0 framing=0 item rc

    # 保护调用者 stdin：scanner / worker 都不得读取它。
    exec 4<&0 </dev/null

    # scanner 输出挂在 fd 3；worker 关闭 0/3/4，stdout/stderr 原样直通。
    while IFS= read -r -d '' item; do
        ((++count)) || :
        WK_IDX=$count worker -- "$item" <&- >&- 2>&- 3>&- 4>&-
        rc=$?
        if (( rc != 0 && firstw == 0 )); then
            firstw=$rc
        fi
    done 3< <(scanner -- "$root")

    # 未被 NUL 终止的尾片段 -> framing=65（不交给 worker）
    item=''
    read -r -u 3 -d '' item || rc=$?
    if (( ${rc:-0} != 0 )) && [[ -n $item ]]; then
        framing=65
    fi

    # 取 scanner 真实退出码（只等本函数启动的那个后台进程替换）
    wait "${PIPESTATUS[0]}" >/dev/null 2>&1 || :
    scanrc=${PIPESTATUS[0]}

    exec 0<&4 4<&- 3<&-

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scanrc" "$firstw" "$framing" >&3

    if (( scanrc != 0 )); then return "$scanrc"; fi
    if (( framing != 0 )); then return "$framing"; fi
    return "$firstw"
}
