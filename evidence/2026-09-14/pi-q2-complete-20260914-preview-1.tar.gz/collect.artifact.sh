collect() {
    local root=$1 item count=0 scan=0 worker=0 framing=0
    local -i fdin fderr rc

    # scanner 的 stdout -> fdin；scanner 的 stderr 直通本函数 stderr。
    exec {fdin}< <(scanner -- "$root" 2>&1-) || return 1
    # worker 的 stderr 转发泵：把管道内容原样写到本函数的 stderr。
    exec {fderr}< <(exec cat >&2) || { exec {fdin}<&-; return 1; }

    while :; do
        if ! IFS= read -r -d '' -u "$fdin" item; then
            # read 因 EOF 失败：item 里是未被 NUL 终止的尾片段（可能为空）。
            [[ -n $item ]] && framing=65
            break
        fi
        (( ++count ))
        # stdin 立即 EOF；stderr 经 fderr 泵原样转发；stdout 直接继承。
        worker -- "$item" 0<&- >&"${fderr}"
        rc=$?
        (( rc != 0 && worker == 0 )) && worker=$rc
    done

    wait "$!" && scan=0 || scan=$?
    exec {fderr}<&- {fdin}<&-

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan" "$worker" "$framing" >&3

    if (( scan != 0 )); then
        return "$scan"
    elif (( framing != 0 )); then
        return "$framing"
    else
        return "$worker"
    fi
}
