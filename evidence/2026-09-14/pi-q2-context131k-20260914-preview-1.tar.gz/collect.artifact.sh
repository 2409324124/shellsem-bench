collect() {
    local root=$1 count=0 firstw=0 scan=0 framing=0 item rc spid wpid
    local -i fd=-1

    # Read the scanner stream on a private FD; never touch the caller's stdin.
    exec {fd}< <(scanner -- "$root" </dev/null) || return 1
    spid=$(exec sh -c 'echo $PPID' <&"$fd") 2>/dev/null   # placeholder, replaced below
    :

    while IFS= read -r -u "$fd" -d '' item; do
        ((count++)) || :
        worker -- "$item" </dev/null >&1 2>&2
        rc=$?
        if (( rc != 0 && firstw == 0 )); then
            firstw=$rc
        fi
    done

    # A non-empty tail without NUL terminator is a framing error.
    IFS= read -r -u "$fd" -t 0.001 item || :
    if [[ -n ${item-} ]]; then
        framing=65
    fi

    wait "$(jobs -p | head -n1)" 2>/dev/null || :
    exec {fd}<&-

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan" "$firstw" "$framing" >&3

    if (( scan != 0 )); then
        return "$scan"
    elif (( framing != 0 )); then
        return "$framing"
    else
        return "$firstw"
    fi
}
