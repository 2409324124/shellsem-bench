collect() {
    local count=0 first_worker_fail=0 scan_rc=0 framing=0
    local item=""

    coproc _SC { scanner -- "$1"; }
    local _rfd="${_SC[0]}"
    local _wfd="${_SC[1]}"
    local _pid="${_SC_PID}"

    # Give scanner immediate EOF on stdin (requirement 3)
    exec {_wfd}>&-

    # Dup coproc read fd to a fixed fd that survives fork/exec
    exec 4<&"$_rfd"
    exec {_rfd}<&-

    while IFS= read -r -d '' item <&4; do
        ((count++)) || true
        worker -- "$item" <&- || {
            local _wrc=$?
            if (( first_worker_fail == 0 )); then
                first_worker_fail=$_wrc
            fi
        }
    done

    # Detect unterminated trailing fragment (requirement 5)
    if [[ -n "$item" ]]; then
        framing=65
    fi

    exec 4<&-

    # Collect scanner's real exit code (requirement 4)
    wait "$_pid" 2>/dev/null || scan_rc=$?

    # Priority: scanner fail > trailing > first worker fail > 0 (requirement 6)
    local ret=0
    if (( scan_rc != 0 )); then
        ret=$scan_rc
    elif (( framing != 0 )); then
        ret=65
    else
        ret=$first_worker_fail
    fi

    # Report status on fd 3 (requirement 7)
    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_rc" "$first_worker_fail" "$framing" >&3

    return "$ret"
}
