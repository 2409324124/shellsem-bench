collect() {
    local root=$1 item='' count=0 scan=0 wrc=0 framing=0 rc=0
    local spid wpid sfd

    exec {sfd}< <(scanner -- "$root") || return 127
    spid=$!

    while IFS= read -r -d '' -u "$sfd" item; do
        ((count++))
        worker -- "$item" </dev/null >&1 2>&2 &
        wpid=$!
        wait "$wpid"; rc=$?
        if (( rc != 0 && wrc == 0 )); then wrc=$rc; fi
    done

    # leftover check: any bytes remaining in stream => unterminated tail
    if read -r -t 0 -u "$sfd" _probe 2>/dev/null; then :; fi
    exec {sfd}<&-
    wait "$spid"; scan=$?
    ...
}
