这是一次 Bash 代码生成测试。**允许使用提供的 read、write、edit、bash 工具验证实现。最终答复仍须满足下述格式。**

只提交修复后的完整 `collect()` 函数，再用不超过 **400 字**解释原代码的问题。不要提交测试框架或额外主程序。

环境为 **GNU Bash 5.2.37、Linux、非交互、非 POSIX 模式，****`LC_ALL=C`**。调用者已经设置：
```bash
set -Eeuo pipefail
shopt -u lastpipe inherit_errexit
set +m
```

没有额外 trap。**FD 3 已打开并可写，专门用于状态报告。**

所有进程最终自行结束，不产生常驻后代进程；不考外部信号、资源不足或底层 I/O 故障。stdout、stderr 的接收端会持续读取。

提供两个**不可修改、不可查看实现**的外部程序：
```text
scanner -- ROOT
worker -- RECORD
```

**`scanner`****&#x20;的行为：**

只向 stdout 输出以 NUL 分隔的记录，stderr 为空。记录可以为空，也可以包含空格、换行、Tab、引号、反斜杠、通配符及任意非 NUL 字节；单条记录不超过 8192 字节。

扫描流可能很大，可能在输出若干完整记录后以非零状态退出，也可能以**没有被 NUL 终止的非空尾片段**结束。空流表示零条记录。

**`worker`****&#x20;的行为：**

stdout、stderr 都可能包含 NUL、任意二进制数据和多个尾部换行；退出码为 0–255。它可能主动读取 stdin。

`ROOT` 和 `RECORD` 必须分别作为单个参数原样传入。

下面是错误实现。你可以重写函数内部，但不能改变接口：
```bash
collect() {
    local count=0 first=0 item

    while IFS= read -r -d '' item; do
        ((count++))

        local data="$(
            worker -- "$item" 2> >(cat >&2) | cat
        )"

        local -a ps=("${PIPESTATUS[@]}")

        if (( ps[0] != 0 && first == 0 )); then
            first=${ps[0]}
        fi

        printf '%s' "$data"
    done < <(scanner -- "$1")

    printf 'count=%d scan=0 worker=%d framing=0\n' \
        "$count" "$first" >&3

    return "$first"
}
```

修复后必须**同时满足以下全部要求**：

1. **完整处理输入。** scanner 恰好运行一次。按输入顺序为每条完整记录调用一次 worker，不并发调用 worker。即使某个 worker 失败，也必须继续处理后续完整记录，读完扫描流并取得 scanner 的真实退出码。未终止尾片段不得交给 worker。
2. **输出逐字节保真。** worker 的 stdout、stderr 分别原样转发到函数的 stdout、stderr，不能增删任何字节。失败时允许已经转发的部分输出保留，不要求回滚。
3. **输入与描述符隔离。** scanner 和每个 worker 的 stdin 都必须立即 EOF，不能消费调用者的 stdin。worker 不能继承用于读取 scanner 输出的文件描述符。
4. **真正流式处理。** 不得把全部扫描结果或 worker 输出放入变量、数组或普通文件。允许保存当前记录、计数和必要的进程状态。
5. **正确收尾。** 返回前必须收集 scanner 状态并关闭本函数创建的文件描述符；不能等待调用者原有的其他后台作业，不能留下本函数启动的后台进程。
6. **返回码有明确优先级。**
   - scanner 非零：返回 scanner 的退出码。
   - 否则，存在未终止尾片段：返回 `65`。
   - 否则，返回输入顺序中第一个失败 worker 的退出码。
   - 都没有：返回 `0`。
7. **报告不能丢信息。** FD 3 上必须且只能打印一行：
   ```text
   count=N scan=S worker=W framing=F
   ```
   行末有一个换行。`N` 是完整记录数，`S` 是 scanner 的真实退出码，`W` 是首个失败 worker 的退出码或 `0`，`F` 在存在未终止尾片段时为 `65`，否则为 `0`。即使高优先级错误覆盖最终返回码，报告仍须保留四项各自的真实值。
8. **实现限制。** 除 scanner、worker 外，只能使用 Bash 内建及 shell 语法；不能调用 cat、其他解释器或外部工具，不能使用 eval、临时文件，也不能改变 shell 选项或安装、修改 trap。函数既可能直接调用，也可能放在：
   ```bash
   if collect "$root"; then
       ...
   fi
   ```
   的条件位置。两种调用位置都必须正确。

不要通过固定返回码或硬编码报告绕过要求。仅提交函数代码和上述短解释。

工具工作目录为 /workspace；bash 为 GNU Bash 5.2.37。隐藏验收数据不可见，不提供答案反馈。
请同时将最终 collect() 函数保存为 /workspace/collect.sh，最终答复仍只含函数与规定的简短解释。
