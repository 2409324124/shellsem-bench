collect() {
    local root=$1
    local count=0 scan_rc=0 worker_rc=0 framing=0 item rc spid

    # Scanner stdout is read on FD 4; its stdin is immediate EOF and its
    # stderr passes through untouched.  The loop runs in the current shell,
    # so counters survive and worker output is byte-exact (no command
    # substitution, no pipeline).
    exec 4< <(scanner -- "$root" </dev/null)
    spid=$!

    while IFS= read -r -u 4 -d '' item; do
        count=$((count + 1))
        # Worker stdin is immediate EOF; it must not inherit FD 4.
        rc=0
        worker -- "$item" </dev/null 4<&- || rc=$?
        if (( rc != 0 && worker_rc == 0 )); then
            worker_rc=$rc
        fi
    done

    # The loop's final failed read leaves any non-NUL-terminated remainder in
    # $item.  That is the tail fragment; it is never handed to a worker.
    # (A further read would clobber it, so test it first.)
    if [[ -n $item ]]; then
        framing=65
    fi
    item=

    # Close our descriptor, then reap the scanner for its real exit status.
    exec 4<&-
    wait "$spid" || scan_rc=$?

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_rc" "$worker_rc" "$framing" >&3

    if (( scan_rc != 0 )); then
        return "$scan_rc"
    elif (( framing != 0 )); then
        return 65
    else
        return "$worker_rc"
    fi
}
