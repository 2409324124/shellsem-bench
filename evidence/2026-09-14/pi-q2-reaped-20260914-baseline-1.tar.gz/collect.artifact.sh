collect() {
    local count=0 first_worker=0 scan_exit=0 has_trailing=0
    local item="" w_rc=0 scan_fd scan_pid

    coproc _SC { scanner -- "$1" <&-; }
    exec {scan_fd}<&"${_SC[0]}"-
    scan_pid=$_SC_PID
    unset _SC _SC_PID

    while IFS= read -r -d '' item <&"$scan_fd"; do
        ((count++)) || true

        w_rc=0
        ( exec {scan_fd}<&-; worker -- "$item" <&- ) || w_rc=$?

        if (( w_rc != 0 && first_worker == 0 )); then
            first_worker=$w_rc
        fi
    done

    [[ -n "$item" ]] && has_trailing=1

    exec {scan_fd}<&-

    wait "$scan_pid" || scan_exit=$?

    local ret=0
    if (( scan_exit != 0 )); then
        ret=$scan_exit
    elif (( has_trailing )); then
        ret=65
    elif (( first_worker != 0 )); then
        ret=$first_worker
    fi

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_exit" "$first_worker" \
        "$(( has_trailing ? 65 : 0 ))" >&3

    return "$ret"
}
