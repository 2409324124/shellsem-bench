All 50 iterations pass. The function is correct and robust.

---

**原代码的问题：**

1. **无法获取 scanner 退出码**：`< <(scanner ...)` 进程替换隐藏了 scanner 的真实退出状态，导致 `scan` 字段始终为 0。
2. **违反流式要求**：`local data="$(worker ... | cat)"` 将 worker 全部输出缓存到变量中；且使用了外部命令 `cat`。
3. **stderr 转发用了 `cat`**：`2> >(cat >&2)` 既使用了禁止的外部工具，又产生不受控的后台进程。
4. **fd 泄漏**：worker 继承了读取 scanner 输出的文件描述符，违反隔离要求。
5. **PIPESTATUS 捕获错误**：在 `local -a ps=("${PIPESTATUS[@]}")` 中，赋值本身重置了 PIPESTATUS，获取的不是内部管道的真实状态。
6. **返回码优先级缺失**：未处理未终止尾片段（应返回 65），且错误地只依赖 worker 状态决定返回值。
7. **`set -e` 下 `((count++))` 致命**：当 count 从 0 增至 1 时表达式值为 0，触发 errexit 终止函数。