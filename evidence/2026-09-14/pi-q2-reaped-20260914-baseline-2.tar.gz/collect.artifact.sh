collect() {
    local count=0 first_worker=0 scan_exit=0 has_trailing=0
    local item wrc scanner_pid

    # Open scanner on fd 4; close scanner's stdin so it gets immediate EOF.
    # $! captures the PID of the process substitution so we can wait for it later.
    exec 4< <(scanner -- "$1" <&-)
    scanner_pid=$!

    while IFS= read -r -d '' item <&4; do
        ((count++)) || true

        # Stream worker output directly to our stdout/stderr (no capture).
        # Close stdin (fd 0), fd 4 (scanner stream) so worker cannot consume them.
        worker -- "$item" <&- 4<&- && wrc=0 || wrc=$?

        if (( wrc != 0 && first_worker == 0 )); then
            first_worker=$wrc
        fi
    done

    # After read -d '' fails: if $item is non-empty, there was an unterminated tail
    if [[ -n "$item" ]]; then
        has_trailing=65
    fi

    # Done reading scanner stream
    exec 4<&-

    # Collect scanner's real exit code
    wait "$scanner_pid" && scan_exit=0 || scan_exit=$?

    # Report all four values on fd 3
    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_exit" "$first_worker" "$has_trailing" >&3

    # Return priority: scanner > trailing > first worker > 0
    if (( scan_exit != 0 )); then
        return "$scan_exit"
    elif (( has_trailing != 0 )); then
        return 65
    elif (( first_worker != 0 )); then
        return "$first_worker"
    else
        return 0
    fi
}
