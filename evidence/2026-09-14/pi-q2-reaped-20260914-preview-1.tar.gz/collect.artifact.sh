collect() {
    local root=$1 item='' count=0 scan=0 worker=0 framing=0 rc
    local -a st

    # fd 3 = scanner stdout, fd 4 = pipe carrying its exit status.
    exec 4< <(scanner -- "$root" >&3 4>&-; printf '%s' "$?" >&4) 3<&-

    while :; do
        item=''
        if IFS= read -r -d '' -u 3 item; then
            :                                   # complete NUL-terminated record
        elif [[ -n $item ]]; then
            framing=65                          # unterminated tail: never fed to worker
        else
            break                               # clean EOF
        fi

        ((count++))

        # stdin is immediate EOF; fds 3 and 4 are closed for worker
        worker -- "$item" <&- 3<&- 4<&- &
        wait "$!"; st=("${PIPESTATUS[@]}")       # survives set -e inside a command list
        if (( st[0] != 0 && worker == 0 )); then worker=${st[0]}; fi
    done

    read -r -u 4 scan || scan=0                  # real scanner status
    exec 3<&- 4<&-                               # close every fd we opened

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan" "$worker" "$framing" >&3

    if (( scan != 0 )); then return "$scan"; fi
    if (( framing != 0 )); then return 65; fi
    return "$worker"
}
