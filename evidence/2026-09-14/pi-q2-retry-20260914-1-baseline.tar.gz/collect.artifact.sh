collect() {
    local count=0 first_worker=0 scan_status=0 has_trailing=0
    local item="" wrc=0

    # Start scanner via coproc so we can retrieve its exit status later.
    coproc _sc { scanner -- "$1"; }
    local _sc_orig=${_sc[0]}
    local _sc_wfd=${_sc[1]}
    local _sc_pid=$_sc_PID

    # Close the write end (scanner doesn't read from pipe).
    exec {_sc_wfd}>&-

    # Duplicate the read fd to a shell-managed variable fd, then release
    # the original coproc read fd so workers cannot inherit it.
    exec {_sc_rfd}<&"$_sc_orig"
    exec {_sc_orig}<&-

    # Read NUL-delimited records from scanner output.
    while true; do
        item=""
        if IFS= read -r -d '' -u "$_sc_rfd" item; then
            # Complete record (NUL-terminated).
            ((count++)) || true

            # Run worker sequentially; stdin is /dev/null (immediate EOF),
            # scanner read fd is closed for worker. stdout/stderr pass through.
            ( exec {_sc_rfd}<&- < /dev/null; worker -- "$item" )
            wrc=$?

            if (( wrc != 0 && first_worker == 0 )); then
                first_worker=$wrc
            fi
        else
            # read failed: EOF or error. Check for unterminated tail fragment.
            if [[ -n "$item" ]]; then
                has_trailing=1
            fi
            break
        fi
    done

    # Collect scanner exit status and close our read fd.
    wait "$_sc_pid" 2>/dev/null
    scan_status=$?
    exec {_sc_rfd}<&- 2>/dev/null || true

    # Compute return code per priority rules.
    local ret=0
    if (( scan_status != 0 )); then
        ret=$scan_status
    elif (( has_trailing )); then
        ret=65
    elif (( first_worker != 0 )); then
        ret=$first_worker
    fi

    # Report on FD 3 (all four fields always reflect true values).
    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_status" "$first_worker" \
        "$(( has_trailing ? 65 : 0 ))" >&3

    return "$ret"
}
