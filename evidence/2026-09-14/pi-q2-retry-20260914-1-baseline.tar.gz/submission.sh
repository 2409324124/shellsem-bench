All edge cases pass. The solution is complete and correct.

---

**原代码问题（≤400字）：**

1. **丢失尾片段**：`read -r -d ''` 失败时直接退出循环，未检测 `$item` 中可能残留的未终止数据，无法报告 `framing=65`。
2. **scanner 退出码丢失**：进程替换 `< <(scanner ...)` 无法获取 scanner 的真实退出码，导致返回码优先级规则失效。
3. **违反流式要求**：`data="$(worker ... | cat)"` 将 worker 全部输出捕获到变量中，且 `$(...)` 会剥离尾部换行，破坏二进制保真。
4. **使用外部命令**：`cat >&2` 和管道中的 `cat` 违反"仅用 bash 内建"的限制。
5. **FD 泄漏给 worker**：worker 继承了读取 scanner 输出的文件描述符，违反隔离要求；worker 的 stdin 也未强制关闭。
6. **PIPESTATUS 误用**：在 `$(...)` 后取 PIPESTATUS 实际反映的是子 shell 内部状态，且因变量捕获已破坏流式语义。
7. **无 FD 清理**：函数未关闭其创建的 FD，可能遗留后台进程。