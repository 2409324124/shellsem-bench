collect() {
    local count=0 first_worker=0 scan_status=0 framing=0
    local item="" has_tail=0 scanner_pid

    exec 4< <(scanner -- "$1" </dev/null)
    scanner_pid=$!

    while true; do
        item=""
        if IFS= read -r -d '' item <&4; then
            ((count++)) || true
            worker -- "$item" </dev/null 4<&-
            local wrc=$?
            if (( wrc != 0 && first_worker == 0 )); then
                first_worker=$wrc
            fi
        else
            if [[ -n "$item" ]]; then
                has_tail=1
                framing=65
            fi
            break
        fi
    done

    exec 4<&-

    wait "$scanner_pid" 2>/dev/null
    scan_status=$?

    local rc=0
    if (( scan_status != 0 )); then
        rc=$scan_status
    elif (( has_tail )); then
        rc=65
    elif (( first_worker != 0 )); then
        rc=$first_worker
    fi

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_status" "$first_worker" "$framing" >&3

    return "$rc"
}
