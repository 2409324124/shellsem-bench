collect() {
    local count=0 first_worker=0 scan_exit=0 has_trailer=0
    local item="" rc=0

    # Run scanner via coproc so we can obtain its exit code via wait.
    # scanner's stdin is closed (/dev/null); we read its stdout from the pipe.
    coproc _SC { scanner -- "$1" < /dev/null; }

    local _rfd="${_SC[0]}"
    local _wfd="${_SC[1]}"
    local _pid="$_SC_PID"

    # Close write end in parent – only scanner writes to this pipe.
    exec {_wfd}>&-

    while IFS= read -r -d '' item; do
        ((count++)) || true

        # Run worker with stdin closed; stdout/stderr pass through directly.
        # Redirect worker's stdin from /dev/null so it cannot consume our stdin.
        # The scanner read fd (_rfd) is not inherited because worker runs in
        # foreground and doesn't need it; however fds are inherited by default.
        # We must explicitly close _rfd for the worker.
        worker -- "$item" < /dev/null {$_rfd}<&- || rc=$?

        if (( rc != 0 && first_worker == 0 )); then
            first_worker=$rc
        fi
    done <&"$_rfd" || true

    # After the read loop: if $item is non-empty, it's an unterminated tail fragment.
    if [[ -n "$item" ]]; then
        has_trailer=1
    fi

    # Close scanner read fd.
    exec {_rfd}<&-

    # Collect scanner's real exit code.
    wait "$_pid" || scan_exit=$?

    # Determine return code per priority rules:
    #   1. scanner non-zero -> scanner exit code
    #   2. unterminated tail fragment -> 65
    #   3. first failed worker -> that worker's exit code
    #   4. otherwise -> 0
    local ret=0
    if (( scan_exit != 0 )); then
        ret=$scan_exit
    elif (( has_trailer != 0 )); then
        ret=65
    elif (( first_worker != 0 )); then
        ret=$first_worker
    fi

    # Report on fd 3: always one line with all four true values.
    local framing=0
    (( has_trailer != 0 )) && framing=65
    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_exit" "$first_worker" "$framing" >&3

    return "$ret"
}
