collect() {
    local count=0 first_worker=0 scan_exit=0 has_trailer=0
    local item="" rc=0

    coproc _SC { scanner -- "$1" < /dev/null; }

    local _rfd="${_SC[0]}"
    local _wfd="${_SC[1]}"
    local _pid="$_SC_PID"

    exec {_wfd}>&-

    while IFS= read -r -d '' item; do
        ((count++)) || true

        worker -- "$item" < /dev/null {$_rfd}<&- || rc=$?

        if (( rc != 0 && first_worker == 0 )); then
            first_worker=$rc
        fi
    done <&"$_rfd" || true

    if [[ -n "$item" ]]; then
        has_trailer=1
    fi

    exec {_rfd}<&-

    wait "$_pid" || scan_exit=$?

    local ret=0
    if (( scan_exit != 0 )); then
        ret=$scan_exit
    elif (( has_trailer != 0 )); then
        ret=65
    elif (( first_worker != 0 )); then
        ret=$first_worker
    fi

    local framing=0
    (( has_trailer != 0 )) && framing=65
    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_exit" "$first_worker" "$framing" >&3

    return "$ret"
}
