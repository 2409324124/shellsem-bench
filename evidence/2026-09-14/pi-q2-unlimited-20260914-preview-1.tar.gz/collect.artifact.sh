collect() {
    # Stream NUL-delimited records from `scanner -- ROOT` into `worker -- RECORD`.
    #
    #   fd 8 : read end of the pipe carrying scanner's stdout (closed before return)
    #   fd 9 : worker's stderr, wired straight to our stderr (no process substitution)
    #
    # The reading loop runs in the *current* shell (input via fd 8), so counters and
    # status variables survive; scanner is reaped with `wait`, leaving no background
    # job behind and never waiting on jobs we did not start.
    local count=0 scan_rc=0 first_worker=0 framing=0 rc=0 item wrc spid scanfd

    exec {scanfd}< <(scanner -- "$1" < /dev/null 9>&-) || return 1
    spid=$!
    eval "exec 8<&$scanfd ${scanfd}<&-"
    exec 0</dev/null

    while IFS= read -r -u 8 -d '' item; do
        count=$((count + 1))
        if worker -- "$item" < /dev/null 9>&2 8>&-; then
            :
        else
            wrc=$?
            if (( first_worker == 0 )); then
                first_worker=$wrc
            fi
        fi
    done

    # A leftover chunk without a terminating NUL is an unterminated tail fragment:
    # it must not be handed to worker, but it does affect framing and the result.
    if IFS= read -r -u 8 -d '' item || [[ -n $item ]]; then
        framing=65
    fi

    exec 8<&- 0<&-
    wait "$spid" || scan_rc=$?

    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_rc" "$first_worker" "$framing" >&3

    if (( scan_rc != 0 )); then
        rc=$scan_rc
    elif (( framing != 0 )); then
        rc=65
    else
        rc=$first_worker
    fi
    return "$rc"
}
