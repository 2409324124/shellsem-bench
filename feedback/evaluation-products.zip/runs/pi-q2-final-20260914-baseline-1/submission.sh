#!/bin/bash
set -Eeuo pipefail
shopt -u lastpipe inherit_errexit
set +m
LC_ALL=C

collect() {
    local count=0 first_worker=0 scan_status=0 has_trailing=0 item=""

    # Allocate a dynamic fd for reading scanner output, so we don't
    # clobber stdin or any other fixed fd.
    exec {_scan_fd}< <(scanner -- "$@")
    local _scanner_pid=$!

    while true; do
        item=""
        if IFS= read -r -d '' -u "$_scan_fd" item; then
            ((count++)) || true

            # Worker gets its own stdin from /dev/null (not ours, not scanner's).
            # Close the scanner-reading fd in the worker subshell so worker
            # cannot inherit it.
            local wc=0
            ( exec {_scan_fd}<&-; worker -- "$item" ) < /dev/null || wc=$?
            if (( wc != 0 && first_worker == 0 )); then
                first_worker=$wc
            fi
        else
            # read failed: EOF or error. Check for unterminated trailing fragment.
            if [[ -n "$item" ]]; then
                has_trailing=65
            fi
            break
        fi
    done

    # Reap scanner to get its true exit status (avoids zombie / PIPESTATUS loss).
    wait "$_scanner_pid"
    scan_status=$?

    # Release the dynamically allocated fd.
    exec {_scan_fd}<&-

    # Report on fd 3 using printf (no cat).
    printf 'count=%d scan=%d worker=%d framing=%d\n' \
        "$count" "$scan_status" "$first_worker" "$has_trailing" >&3

    # Exit priority: scanner > framing > worker.
    if (( scan_status != 0 )); then
        return "$scan_status"
    elif (( has_trailing != 0 )); then
        return 65
    elif (( first_worker != 0 )); then
        return "$first_worker"
    else
        return 0
    fi
}
